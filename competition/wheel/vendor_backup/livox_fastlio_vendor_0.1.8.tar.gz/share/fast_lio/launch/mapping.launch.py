import os.path

import subprocess

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, OpaqueFunction
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource

from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    package_path = get_package_share_directory('fast_lio')
    
    default_config_path = os.path.join(package_path, 'config')
    
    default_rviz_config_path = os.path.join(
        package_path, 'rviz', 'fastlio.rviz')

    use_sim_time = LaunchConfiguration('use_sim_time')
    config_path = LaunchConfiguration('config_path')
    config_file = LaunchConfiguration('config_file')
    rviz_use = LaunchConfiguration('rviz')
    rviz_cfg = LaunchConfiguration('rviz_cfg')
    start_livox = LaunchConfiguration('start_livox')
    livox_pkg = LaunchConfiguration('livox_pkg')
    livox_launch = LaunchConfiguration('livox_launch')
    livox_launch_dir = LaunchConfiguration('livox_launch_dir')

    declare_use_sim_time_cmd = DeclareLaunchArgument(
        'use_sim_time', default_value='false',
        description='Use simulation (Gazebo) clock if true'
    )
    declare_config_path_cmd = DeclareLaunchArgument(
        'config_path', default_value=default_config_path,
        description='Yaml config file path'
    )
    decalre_config_file_cmd = DeclareLaunchArgument(
        'config_file', default_value='mid360.yaml',
        description='Config file'
    )
    declare_rviz_cmd = DeclareLaunchArgument(
        'rviz', default_value='true',
        description='Use RViz to monitor results'
    )
    declare_rviz_config_path_cmd = DeclareLaunchArgument(
        'rviz_cfg', default_value=default_rviz_config_path,
        description='RViz config file path'
    )
    declare_start_livox = DeclareLaunchArgument(
        'start_livox', default_value='true',
        description='Start Livox driver if not already running')
    declare_livox_pkg = DeclareLaunchArgument(
        'livox_pkg', default_value='livox_ros_driver2',
        description='Livox driver package name')
    declare_livox_launch = DeclareLaunchArgument(
        'livox_launch', default_value='msg_MID360_launch.py',
        description='Livox driver launch file')
    declare_livox_launch_dir = DeclareLaunchArgument(
        'livox_launch_dir', default_value='launch_ROS2',
        description='Livox driver launch directory (e.g. launch or launch_ROS2)')

    fast_lio_node = Node(
        package='fast_lio',
        executable='fastlio_mapping',
        parameters=[PathJoinSubstitution([config_path, config_file]),
                    {'use_sim_time': use_sim_time}],
        output='screen'
    )
    livox_launch_path = PathJoinSubstitution(
        [
            FindPackageShare(livox_pkg),
            livox_launch_dir,
            livox_launch,
        ]
    )
    livox_include = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(livox_launch_path),
        condition=IfCondition(start_livox),
    )
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_cfg],
        condition=IfCondition(rviz_use)
    )

    ld = LaunchDescription()
    ld.add_action(declare_use_sim_time_cmd)
    ld.add_action(declare_config_path_cmd)
    ld.add_action(decalre_config_file_cmd)
    ld.add_action(declare_rviz_cmd)
    ld.add_action(declare_rviz_config_path_cmd)
    ld.add_action(declare_start_livox)
    ld.add_action(declare_livox_pkg)
    ld.add_action(declare_livox_launch)
    ld.add_action(declare_livox_launch_dir)

    def maybe_launch_livox(context, *args, **kwargs):
        start_flag = context.perform_substitution(start_livox).lower()
        if start_flag in ('false', '0', 'off'):
            return []
        nodes = []
        try:
            result = subprocess.run(
                ['ros2', 'node', 'list'],
                check=False,
                capture_output=True,
                text=True,
                timeout=2,
            )
            nodes = [line.strip() for line in result.stdout.splitlines()]
        except Exception as exc:
            print(f"[fast_lio.launch] ros2 node list check failed ({exc}), starting Livox driver.")
        if '/livox_lidar_publisher' in nodes:
            print("[fast_lio.launch] Livox driver already running; skip starting livox_ros_driver2.")
            return []
        print("[fast_lio.launch] Livox driver not detected; launching livox_ros_driver2.")
        return [livox_include]

    # ld.add_action(OpaqueFunction(function=maybe_launch_livox))
    ld.add_action(fast_lio_node)
    ld.add_action(rviz_node)

    return ld
